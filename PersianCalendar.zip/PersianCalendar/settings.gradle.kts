rootProject.buildFileName = "build.gradle.kts"
include(":PersianCalendar")
